package com.myroutine.app

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

private val Ink = Color(0xFF172033)
private val Muted = Color(0xFF788397)
private val Blue = Color(0xFF3978F6)
private val Canvas = Color(0xFFF4F6FA)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { RoutineApp(this) }
    }
    override fun onResume() {
        super.onResume()
        ReminderScheduler.scheduleAll(this)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutineApp(activity: MainActivity) {
    var tasks by remember { mutableStateOf(RoutineStore.load(activity)) }
    var selectedTab by remember { mutableIntStateOf(0) }
    val done = remember { mutableStateListOf<Int>() }
    val now = Calendar.getInstance()
    val greeting = when (now.get(Calendar.HOUR_OF_DAY)) { in 5..11 -> "শুভ সকাল"; in 12..16 -> "শুভ দুপুর"; in 17..20 -> "শুভ সন্ধ্যা"; else -> "শুভ রাত্রি" }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Canvas, surface = Color.White)) {
        Scaffold(
            containerColor = Canvas,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Rounded.CalendarToday, null) }, label = { Text("রুটিন") })
                    NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Rounded.Tune, null) }, label = { Text("সেটিংস") })
                }
            }
        ) { padding ->
            if (selectedTab == 0) {
                LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Spacer(Modifier.height(18.dp))
                        Text("MY ROUTINE", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text(greeting + " 👋", color = Ink, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                        Text("আজ নিজের জন্য একটু সময় রাখো।", color = Muted, fontSize = 14.sp)
                        Spacer(Modifier.height(8.dp))
                        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(18.dp)) {
                                Text("আজকের অগ্রগতি", color = Muted, fontSize = 13.sp)
                                Text("${done.size} / ${tasks.size} কাজ সম্পন্ন", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                                LinearProgressIndicator(progress = { if (tasks.isEmpty()) 0f else done.size.toFloat()/tasks.size }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp), color = Blue, trackColor = Color(0xFFE8EDF6))
                            }
                        }
                        Text("আজকের রুটিন", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    }
                    items(tasks.sortedBy { it.time }, key = { it.id }) { task ->
                        TaskCard(task, done.contains(task.id),
                            onDone = { if (!done.contains(task.id)) done.add(task.id) else done.remove(task.id) },
                            onToggle = { enabled ->
                                val updated = task.copy(enabled = enabled); RoutineStore.save(activity, updated)
                                tasks = tasks.map { if (it.id == task.id) updated else it }; ReminderScheduler.schedule(activity, updated)
                            },
                            onMode = { mode ->
                                val updated = task.copy(mode = mode); RoutineStore.save(activity, updated)
                                tasks = tasks.map { if (it.id == task.id) updated else it }; ReminderScheduler.schedule(activity, updated)
                            },
                            onTime = {
                                val parts = task.time.split(":")
                                TimePickerDialog(activity, { _, h, m ->
                                    val updated = task.copy(time = "%02d:%02d".format(h,m)); RoutineStore.save(activity, updated)
                                    tasks = tasks.map { if (it.id == task.id) updated else it }; ReminderScheduler.schedule(activity, updated)
                                }, parts[0].toInt(), parts[1].toInt(), false).show()
                            })
                    }
                    item { Spacer(Modifier.height(12.dp)) }
                }
            } else {
                SettingsScreen(activity)
            }
        }
    }
}

@Composable
fun TaskCard(task: RoutineTask, isDone: Boolean, onDone: () -> Unit, onToggle: (Boolean) -> Unit, onMode: (AlertMode) -> Unit, onTime: () -> Unit) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(task.title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Text(task.time, color = Blue, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                }
                Switch(checked = task.enabled, onCheckedChange = onToggle)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onTime, contentPadding = PaddingValues(horizontal = 10.dp)) {
                    Icon(Icons.Rounded.Schedule, null, Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text("সময়")
                }
                var expanded by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { expanded = true }, contentPadding = PaddingValues(horizontal = 10.dp)) {
                        Icon(if (task.mode == AlertMode.FULL_SCREEN) Icons.Rounded.Call else Icons.Rounded.Notifications, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(5.dp)); Text(if (task.mode == AlertMode.FULL_SCREEN) "Call Style" else "Notification")
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        DropdownMenuItem(text = { Text("সাধারণ Notification") }, onClick = { onMode(AlertMode.NOTIFICATION); expanded = false })
                        DropdownMenuItem(text = { Text("Full-screen Alarm") }, onClick = { onMode(AlertMode.FULL_SCREEN); expanded = false })
                    }
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDone) { Text(if (isDone) "সম্পন্ন ✓" else "Done") }
            }
        }
    }
}

@Composable
fun SettingsScreen(activity: MainActivity) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("সেটিংস", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("অ্যালার্ম অনুমতি", color = Ink, fontWeight = FontWeight.Bold)
                Text("সময়মতো অ্যালার্মের জন্য Notification, Exact Alarm এবং Full-screen alert অনুমতি চালু রাখো।", color = Muted, fontSize = 13.sp)
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= 31) {
                        activity.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${activity.packageName}")))
                    } else {
                        activity.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName))
                    }
                }) { Text("Exact Alarm Permission") }
                OutlinedButton(onClick = {
                    if (Build.VERSION.SDK_INT >= 34) {
                        activity.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${activity.packageName}")))
                    } else {
                        activity.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName))
                    }
                }) { Text("Full-screen Permission") }
                OutlinedButton(onClick = {
                    activity.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${activity.packageName}")))
                }) { Text("App & Battery Settings") }
            }
        }
        Text("সব রুটিন ও সময় ফোনে সংরক্ষিত থাকে। ইন্টারনেট প্রয়োজন নেই।", color = Muted, fontSize = 13.sp)
    }
}
