package com.myroutine.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("task_id", 0)
        val title = intent.getStringExtra("task_title") ?: "My Routine Reminder"
        val mode = intent.getStringExtra("task_mode") ?: AlertMode.NOTIFICATION.name
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "routine_alarm"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Routine alarms", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Daily routine reminders"
                enableVibration(true)
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), null)
            }
            manager.createNotificationChannel(channel)
        }
        val alarmIntent = Intent(context, AlarmActivity::class.java).putExtra("task_title", title).putExtra("task_id", id)
        val fullPi = PendingIntent.getActivity(context, id + 1000, alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText("তোমার রুটিনের সময় হয়েছে")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(fullPi)
        if (mode == AlertMode.FULL_SCREEN.name) builder.setFullScreenIntent(fullPi, true)
        manager.notify(id, builder.build())

        // Schedule this task for tomorrow after it fires.
        val task = RoutineStore.load(context).firstOrNull { it.id == id }
        if (task != null && task.enabled) ReminderScheduler.schedule(context, task)
    }
}
