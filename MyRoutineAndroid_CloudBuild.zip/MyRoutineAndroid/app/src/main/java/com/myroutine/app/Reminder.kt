package com.myroutine.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

enum class AlertMode { NOTIFICATION, FULL_SCREEN }

data class RoutineTask(
    val id: Int,
    val title: String,
    val time: String,
    val mode: AlertMode = AlertMode.NOTIFICATION,
    val enabled: Boolean = true
)

object RoutineStore {
    private const val PREF = "routine_store"
    private val defaults = listOf(
        RoutineTask(1, "ঘুম থেকে ওঠা ও পানি পান", "06:30", AlertMode.FULL_SCREEN),
        RoutineTask(2, "দাঁত ব্রাশ ও ফ্রেশ হওয়া", "06:50"),
        RoutineTask(3, "সকালের Acne Gel", "07:00", AlertMode.FULL_SCREEN),
        RoutineTask(4, "গোসল ও প্রস্তুতি", "07:30"),
        RoutineTask(5, "সকালের নাশতা", "08:00"),
        RoutineTask(6, "কলেজে যাওয়ার প্রস্তুতি", "09:10", AlertMode.FULL_SCREEN),
        RoutineTask(7, "দুপুরের খাবার ও নামাজের বিরতি", "12:00"),
        RoutineTask(8, "কোর্স শেষ ও বিরতি", "16:30"),
        RoutineTask(9, "হাঁটা ও ব্যায়াম", "17:00", AlertMode.FULL_SCREEN),
        RoutineTask(10, "কোর্স রিভিশন / নতুন স্কিল", "18:30"),
        RoutineTask(11, "রাতের খাবার", "20:00"),
        RoutineTask(12, "রাতের Skin Care", "21:00"),
        RoutineTask(13, "ফোন দূরে রাখো", "22:00"),
        RoutineTask(14, "ঘুমানোর সময়", "22:30", AlertMode.FULL_SCREEN)
    )

    fun load(context: Context): List<RoutineTask> {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        return defaults.map { d ->
            val time = p.getString("time_${d.id}", d.time) ?: d.time
            val enabled = p.getBoolean("enabled_${d.id}", d.enabled)
            val mode = runCatching { AlertMode.valueOf(p.getString("mode_${d.id}", d.mode.name)!!) }.getOrDefault(d.mode)
            d.copy(time = time, enabled = enabled, mode = mode)
        }
    }

    fun save(context: Context, task: RoutineTask) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("time_${task.id}", task.time)
            .putBoolean("enabled_${task.id}", task.enabled)
            .putString("mode_${task.id}", task.mode.name)
            .apply()
    }
}

object ReminderScheduler {
    fun scheduleAll(context: Context) = RoutineStore.load(context).forEach { schedule(context, it) }

    fun schedule(context: Context, task: RoutineTask) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("task_id", task.id)
            .putExtra("task_title", task.title).putExtra("task_mode", task.mode.name)
        val pi = PendingIntent.getBroadcast(context, task.id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (!task.enabled) {
            am.cancel(pi)
            return
        }
        val parts = task.time.split(":")
        if (parts.size != 2) return
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, parts[0].toIntOrNull() ?: 8)
            set(Calendar.MINUTE, parts[1].toIntOrNull() ?: 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        }
    }
}
