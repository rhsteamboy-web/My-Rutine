package com.myroutine.app

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class AlarmActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = intent.getStringExtra("task_title") ?: "রুটিনের সময় হয়েছে"
        setContent {
            var dismissed by remember { mutableStateOf(false) }
            Surface(Modifier.fillMaxSize(), color = Color(0xFFF4F6FA)) {
                Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Rounded.Alarm, null, Modifier.size(64.dp), tint = Color(0xFF3978F6))
                    Spacer(Modifier.height(24.dp))
                    Text("MY ROUTINE", color = Color(0xFF3978F6), fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Spacer(Modifier.height(12.dp))
                    Text(title, fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color(0xFF172033))
                    Text("এখন কাজটি করার সময়।", color = Color(0xFF788397))
                    Spacer(Modifier.height(32.dp))
                    Button(onClick = { dismissed = true; finish() }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                        Text("ঠিক আছে")
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { finish() }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                        Text("বন্ধ করো")
                    }
                }
            }
        }
    }
}
