# My Routine — Android project

এটি My Routine অ্যাপের প্রথম MVP Android Studio project।

## ফিচার
- Light + Apple-inspired UI
- বাংলা daily routine list
- ১৪টি প্রাথমিক routine task
- প্রতিটি task আলাদাভাবে enable/disable
- প্রতিটি task-এর সময় পরিবর্তন
- Notification অথবা Full-screen Alarm mode নির্বাচন
- ফোন restart হলে reminder পুনরায় schedule করার receiver
- লোকাল SharedPreferences storage; ইন্টারনেট লাগে না

## Build
1. Android Studio-তে এই project folder খুলুন।
2. Gradle sync সম্পন্ন হতে দিন।
3. Android SDK 35 ইনস্টল করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- Android 12+ এ Exact Alarm permission Settings থেকে চালু করতে হতে পারে।
- Android 14+ এ Full-screen intent permission/eligibility ডিভাইস ও OS নীতির ওপর নির্ভর করে। এটি সব ডিভাইসে জোর করে দেখানো যায় না।
- কিছু ফোনের battery optimization/background restrictions অ্যালার্ম বিলম্বিত করতে পারে; App info থেকে প্রয়োজনীয় অনুমতি দিন।
- Notification channel তৈরি হওয়ার পর sound setting Android Settings থেকে নিয়ন্ত্রণ করা যায়।
- এই MVP-তে task completion counter app খোলা অবস্থায়/চলতি session-এ থাকে; স্থায়ী daily history পরের সংস্করণে যোগ করা উচিত।
- এটি SIM call বা SMS পাঠায় না; call-style হলো অ্যাপের নিজস্ব full-screen alarm UI।
- ওষুধের সময় এখানে placeholder; ব্যবহারকারীকে প্রেসক্রিপশন অনুযায়ী সময় ঠিক করতে হবে।
